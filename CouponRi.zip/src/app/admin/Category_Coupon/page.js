
import AddCategoryCoupons from "./AddCategoryCoupon";

export default function Categories(){
  return (
    <>
      <AddCategoryCoupons/>
      
    </>
  );
};

