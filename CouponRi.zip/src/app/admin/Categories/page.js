import AddCategories from "./AddCategories";

export default function Categories(){
  return (
    <>
      <AddCategories />
      
    </>
  );
};

