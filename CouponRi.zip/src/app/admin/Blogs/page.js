'use client'
import AddBlogs from "./AddBlogs";

export default function Blogs() {
  return (
    <>
      <AddBlogs />
    </>
  );
}
